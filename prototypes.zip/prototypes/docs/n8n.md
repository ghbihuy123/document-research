# N8N

## Introduce

n8n (pronounced "n-eight-n") is a free and source-available workflow automation tool that enables you to connect different services and automate tasks using a visual editor. It's designed to give you full control over your data and workflows, allowing complex integrations without writing code.

## What is n8n

n8n is a workflow automation platform that supports over 300 integrations out of the box. It allows users to create, trigger, and manage workflows that connect APIs, databases, and custom scripts — all using a low-code interface. It can run locally, in the cloud, or in containers like Docker.

## Why n8n

- Open Source: Self-host and fully customize.
- Low Code / No Code: Drag-and-drop workflow builder with conditional logic and loops.
- Extensible: Create your own nodes or extend existing ones.
- Data Control: Run on your infrastructure with full control over data privacy.
- Queue/Worker Architecture: Supports scalable workloads with workers for job processing.

## How n8n

n8n works as a server with a UI for building workflows and a backend for executing them. It supports event triggers (e.g., webhooks, schedules, or queues) and processes jobs either on the main service or via distributed workers (ideal for scaling in production).

A typical deployment consists of:
- A main n8n service (UI and API)
- One or more workers for executing jobs
- A PostgreSQL database for persistent storage
- A Redis instance for job queue management

## Prerequisite Services

- Postgres – stores workflows, credentials, executions, and settings.
- Redis – manages the job queue when running n8n in queue mode.
- N8N Service – the main service for the web UI and REST API.
- N8N Worker – background job processor that executes queued workflows.

## Reference

- Docker Compose from Official n8n Repo  
  https://github.com/n8n-io/n8n-hosting/blob/main/docker-compose/withPostgresAndWorker/docker-compose.yml

- Official Documentation  
  https://docs.n8n.io/hosting/installation/docker/

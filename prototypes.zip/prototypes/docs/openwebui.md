# OpenWebUI

## Introduce

OpenWebUI is an open-source web-based interface designed to work with AI models and services like Ollama, OpenAI, and others. It provides an intuitive chat-based UI, image generation capabilities, RAG (retrieval augmented generation) support, and advanced configuration options for developers and researchers looking to build or customize their own AI assistant experience.

## What is OpenWebUI

OpenWebUI is a feature-rich frontend interface for interacting with large language models (LLMs) through local or remote backends such as Ollama, OpenAI, and other API-compatible platforms. It provides chat history, markdown rendering, PDF parsing, search-enhanced RAG queries, and multi-model handling out of the box.

## Why OpenWebUI

- **Open Source** and customizable
- Clean and modern **chat interface**
- Supports **local inference** (via Ollama) and **cloud APIs** (like OpenAI)
- Integrated features like **web search**, **PDF support**, and **image generation**
- Deployable via Docker or on cloud platforms
- Supports Redis queues and background workers for scalability

## How OpenWebUI

OpenWebUI is typically deployed as a containerized web application that connects to a backend LLM (e.g., via Ollama or OpenAI API). It uses Redis for queue management, and optionally connects to Postgres and Minio for data persistence and file handling. The system exposes a web-based UI where users can interact with models, upload documents, and perform web-based search and scraping tasks.

### Presquite Services

- **Minio** – Optional S3-compatible storage backend for managing documents and file uploads
- **Postgres** – Used for storing user data, chat history, and configuration
- **OpenWebUI** – The main application providing the web interface and backend logic

## Reference

### Official Document  
- https://docs.openwebui.com/

### Environment Variables  
- https://docs.openwebui.com/getting-started/env-configuration

### Docker Compose  
- https://github.com/open-webui/pipelines/blob/main/docker-compose.yaml
